#include "Game.h"

int main()
{
	// Create an instance of the Game class and run it
	Game mygame;
	mygame.run();
	return 0;

}
